// diag-live.cjs — 诊断：连接 mux 打印 15s 内收到的所有帧类型
const BASE = "http://127.0.0.1:46322";
const ws = new WebSocket(BASE + "/api/events.mux");
let n = 0;
ws.onopen = () => {
  console.log("OPEN — 等待 15s 收集帧…");
};
ws.onmessage = (m) => {
  n++;
  let p;
  try { p = JSON.parse(m.data); } catch { console.log("FRAME#" + n + " non-json:", String(m.data).slice(0, 100)); return; }
  const pl = p.payload || {};
  console.log("FRAME#" + n, p.type, "|", pl.type, pl.sessionId ? "sid=" + pl.sessionId.slice(0, 16) : "", pl.lastSeq !== undefined ? "lastSeq=" + pl.lastSeq : "", pl.event ? "ev=" + pl.event.type : "");
};
ws.onerror = (e) => console.log("ERROR", e.message || e.type);
setTimeout(() => {
  console.log("DONE total=" + n);
  ws.close();
  process.exit(0);
}, 15000);