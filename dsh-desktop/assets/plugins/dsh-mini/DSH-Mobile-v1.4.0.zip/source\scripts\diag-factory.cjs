// diag-factory.cjs — 在 Node 中 mock 浏览器环境，执行 lib/client.js 的 factory，
// 验证 materialize 阶段是否有运行时错误（Node 给出精确堆栈）。
// 用法: node scripts/diag-factory.cjs
const fs = require("fs");
const path = require("path");

const bundlePath = path.join(__dirname, "..", "lib", "client.js");
const code = fs.readFileSync(bundlePath, "utf8");

let captured = null;
const beacons = [];
const calls = [];

// mock fetch（factory 顶层 beacon 会调用）
global.fetch = (url, init) => {
  beacons.push({ url: String(url), init });
  return Promise.resolve({ ok: true, catch() {} });
};
// 浏览器全局（QR vendor 库可能需要 document/window）
global.window = { __ModuleLoader__: { load(def) { captured = def; } }, dshDesktop: undefined, dshMiniBridge: undefined };
global.document = { querySelectorAll: () => [], createElement: () => ({ style: {} }), head: { appendChild() {} } };
global.navigator = { userAgent: "diag" };
global.location = { origin: "http://127.0.0.1:46321" };
global.console = console;

try {
  // 执行 bundle 顶层（window.__ModuleLoader__.load 调用）
  new Function("window", "document", "navigator", "location", "fetch", code)(window, document, navigator, location, fetch);
  console.log("bundle top-level executed; captured =", !!captured);
  if (!captured) {
    console.log("FAIL: __ModuleLoader__.load 未被调用");
    process.exit(1);
  }
  console.log("bundle id =", captured.id);

  // mock require: 提供 platform seed 模块的 stub（materialize 只取引用，不渲染）
  const reactStub = {
    useState: () => ["", () => {}],
    useEffect: () => {},
    useRef: () => ({ current: null }),
    useMemo: (f) => f(),
    useCallback: (f) => f,
    createElement: (...a) => a,
  };
  const requireStub = (spec) => {
    calls.push(spec);
    if (spec === "react") return reactStub;
    if (spec === "react-dom/client") return { createRoot: () => ({ render() {}, unmount() {} }) };
    if (spec === "react/jsx-runtime") return { jsx: (...a) => a, jsxs: (...a) => a };
    throw new Error("unexpected require specifier: " + spec);
  };

  const exportsObj = captured.factory(requireStub);
  console.log("factory returned; keys =", Object.keys(exportsObj || {}));
  console.log("typeof apply =", typeof (exportsObj && exportsObj.apply));
  console.log("inject =", JSON.stringify(exportsObj && exportsObj.inject));
  console.log("require specs used =", JSON.stringify(calls));
  console.log("factory beacons =", JSON.stringify(beacons));
  console.log("RESULT: PASS (factory materialize 无运行时错误)");
} catch (e) {
  console.log("RESULT: FAIL — factory 抛错:");
  console.log(e && e.stack ? e.stack : e);
  process.exit(2);
}
