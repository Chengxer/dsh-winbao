// diag-ws.cjs — 最小 WS 诊断：连接 mux 流打印收到的原始帧（最多 5 条）
const BASE = "http://127.0.0.1:46322";
const url = BASE + "/api/events.mux";
console.log("connecting", url);
const ws = new WebSocket(url);
let n = 0;
const timer = setTimeout(() => {
  console.log("TIMEOUT after", n, "frames");
  ws.close();
  process.exit(0);
}, 10000);
ws.onopen = () => console.log("OPEN");
ws.onmessage = (m) => {
  n++;
  console.log("FRAME#" + n + ":", String(m.data).slice(0, 300));
  if (n >= 5) {
    clearTimeout(timer);
    ws.close();
    process.exit(0);
  }
};
ws.onerror = (e) => console.log("ERROR", e.message || e.type || "?");
ws.onclose = (e) => console.log("CLOSE code=" + e.code + " reason=" + e.reason);
setTimeout(() => {
  console.log("GIVEUP");
  process.exit(1);
}, 15000);