DSH Mobile v1.4.0 — 官方 GUI 手机桥发行包（v3 移植版）
====================================================

手机端：手机 WebView/浏览器打开 http://<电脑IP>:46322/?token=... 直接进入官方 DSH GUI
（走 dsh-mini 网关：RPC + 双 WS 事件流 + 静态 bundle 全由 dsh-mini 自建）

安装（PowerShell，仓库根目录执行）：
  pwsh scripts/install.ps1
  或指定安装目录：
  pwsh scripts/install.ps1 -Target "C:\Program Files\DSH Desktop\resources\app"

装完重启 DSH Desktop。之后：
  1. DSH 设置 → 「DSH Mobile 手机桥」→ 开启「局域网网关」（DSH web 需 --host 0.0.0.0 才能被手机访问）
  2. 桌面侧栏点「手机连接」图标 → 弹二维码（内容为 http://<电脑IP>:<网关端口>/?token=...）
  3. 手机装 APK（source/apk/ 工程，构建见 apk/README-APK.md）内扫码，或手机浏览器直接打开该地址

详细文档：README.md / SPEC.md / SPEC-v3-GUI-移植.md